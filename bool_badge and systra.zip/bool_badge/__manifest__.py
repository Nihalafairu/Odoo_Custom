{
    "name": "Bool Badge",
    "depends": ['web'],
    "assets":
        {"web.assets_backend":[
            "/bool_badge/static/src/js/bool_badge.js",
            "/bool_badge/static/src/xml/bool_badge.xml"

            ]
        }

}
