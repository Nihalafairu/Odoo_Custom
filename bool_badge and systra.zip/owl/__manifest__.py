{
    "name": "Systray Increment",
    "depends": ['web'],
    "assets":
        {"web.assets_backend":
            [
        "owl/static/src/js/increment.js",
        "owl/static/src/xml/Increment.xml"
    ]
        }

}
