{
    'name': "Purchase DEscription",
    'version': '16.0.1.1.1',
    'category': 'purchase description ',
    'depends': ['base', 'product','purchase','sale','stock'],
    'author': "Nihala",
    'description': "",
    'data': [

    ],
    'installable': True,
}
