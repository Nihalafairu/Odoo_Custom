from odoo import models


class PurchaseDescription(models.Model):
    _inherit = "sale.order"

    def action_confirm(self):
        """function to pass the description entered by the user in sale order line to purchase order line """
        res = super().action_confirm()
        for line in self.order_line:
            for route in line.product_id.route_ids:
                if route.name == 'Replenish on Order (MTO)':
                    order = line._purchase_service_create()
                    for sale_line, purchase_line in order.items():
                        purchase_line.name = sale_line.name
        return res
