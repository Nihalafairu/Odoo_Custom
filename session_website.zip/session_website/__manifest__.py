{
    'name': "Session Website",
    'version':"16.0.1.0.0",
    'depends':['website'],
    'data':[
        'data/website_view.xml',
        'views/partner_template_view.xml',
    ]

}